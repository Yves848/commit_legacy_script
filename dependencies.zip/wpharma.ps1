﻿$DBPath = "C:\WPHARMA\DB\"
$path = Read-Host "Chemin de l'archive WPHARMA.zip :"

if (!(Test-Path $path)) {
    Write-Host "L'archive WPHARMA.zip n'a pas été trouvée au chemin indiqué."
    $path = Read-Host "Chemin de WPHARMA.zip :"
} 

# Récupérer le chemin courant et le décomposer en tableau
$LocalPath = (get-location).Path -split "\\"
# Construire le chemin du commit en retirant les 5 derniers éléments du tableau => Suppression des ..\..\..\.. illisibles 😊
$commitPath = $LocalPath[0..($LocalPath.Length - 5)] -join "\"

$destination = "C:\"
if (Test-Path "C:\WPHARMA") {
    Write-Host "Le dossier WPHARMA existe déjà, il va être renommé en WPHARMA_old."
    Rename-Item -Path "C:\WPHARMA" -NewName "WPHARMA_old"
}
Expand-Archive -Path $path -DestinationPath $destination
Write-Host "WPHARMA a été décompressé dans C:\."
Write-Host "Copie des dll en cours"
if (Test-Path "C:\WPHARMA\wpodbc3.dll") {
    Copy-Item -Path "C:\WPHARMA\wpodbc3.dll" -Destination "$commitpath\wpodbc3.dll" -Force
}
else {
    Copy-Item -Path "wpodbc3.dll" -Destination "$commitpath\wpodbc3.dll" -Force
}

if (Test-Path "C:\WPHARMA\wpodbc3r.dll") {
    Copy-Item -Path "C:\WPHARMA\wpodbc3r.dll" -Destination "$commitpath\wpodbc3r.dll" -Force
}
else {
    Copy-Item -Path "wpodbc3r.dll" -Destination "$commitpath\wpodbc3r.dll" -Force
}

Copy-Item -Path "C:\WPHARMA\evncall.dll" -Destination "$commitpath\evncall.dll" -Force



Write-Host "Remplacement du system.myd"
if (Test-Path "C:\WPHARMA\DB\SYSTEM.MYD") {
    Rename-Item -Path  "C:\WPHARMA\DB\SYSTEM.MYD" -NewName "SYSTEM.MYD_old"
}
Copy-Item -Path "SYSTEM.MYD" -Destination "C:\WPHARMA\DB\SYSTEM.MYD"


Write-Host "Renommage des fichiers de la base de données"

$databaseFiles = @(
    "clients",
    "orders",
    "benefic",
    "fourep",
    "medecin"
)

$databaseFiles | ForEach-Object {
    Write-Host "Renommage des fichiers $_"
    $sourceFile = $DBPath + "$_.myd"
    $destinationFile = $DBPath + "$($_)0.myd"
    Copy-Item -Path $sourceFile -Destination $destinationFile -Force

    $sourceFile = $DBPath + "$_.myi"
    $destinationFile = $DBPath + "$($_)0.myi"
    Copy-Item -Path $sourceFile -Destination $destinationFile -Force

    $sourceFile = $DBPath + "$_.frm"
    $destinationFile = $DBPath + "$($_)0.frm"
    Copy-Item -Path $sourceFile -Destination $destinationFile -Force
}

Read-Host -Prompt "Appuyez sur la touche entrée pour continuer..."